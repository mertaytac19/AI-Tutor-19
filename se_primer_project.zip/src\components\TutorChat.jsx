// src/components/TutorChat.jsx
import React, { useState } from "react";
import { useStore } from "../store";

export default function TutorChat() {
  const { profile } = useStore();
  const [messages, setMessages] = useState([
    { from: "tutor", text: "What do you think could be causing the duplicate allocations?" }
  ]);
  const [input, setInput] = useState("");

  const sendMessage = async () => {
    if (!input.trim()) return;
    const userMsg = { from: "user", text: input };
    setMessages(prev => [...prev, userMsg]);
    setInput("");
    // Simulate calling backend Tutor API (placeholder)
    const reply = await mockTutorResponse(input);
    setMessages(prev => [...prev, { from: "tutor", text: reply }]);
  };

  // Simple mock that returns a Socratic question based on keywords
  const mockTutorResponse = async (msg) => {
    const low = profile.experience === "low";
    const lower = msg.toLowerCase();
    if (lower.includes("lock")) {
      return low
        ? "Can you think of a way to ensure only one request modifies the allocation state at a time?"
        : "What trade‑offs exist between coarse‑grained and fine‑grained locking here?";
    }
    if (lower.includes("queue")) {
      return low
        ? "How might a message queue help to serialize the allocation work?"
        : "What guarantees would a queue give you compared to a lock?";
    }
    if (lower.includes("log")) {
      return low
        ? "Why is it risky to share raw GPS coordinates with external services?"
        : "What data‑masking technique would satisfy GDPR/KVKK compliance?";
    }
    // Default Socratic fallback
    return low
      ? "What other aspects of the system could be influencing this race condition?"
      : "Which part of the architecture do you suspect is the weakest link?";
  };

  return (
    <div className="mt-6 border-t pt-4">
      <h3 className="text-lg font-medium mb-2">AI Tutor</h3>
      <div className="h-48 overflow-y-auto bg-gray-50 p-2 rounded mb-2">
        {messages.map((m, i) => (
          <p key={i} className={m.from === "tutor" ? "text-indigo-700" : "text-gray-800"}>
            <strong>{m.from === "tutor" ? "Tutor" : "You"}:</strong> {m.text}
          </p>
        ))}
      </div>
      <div className="flex space-x-2">
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          className="flex-1 border rounded px-2 py-1"
          placeholder="Ask the tutor…"
        />
        <button
          onClick={sendMessage}
          className="px-4 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded"
        >
          Send
        </button>
      </div>
    </div>
  );
}
