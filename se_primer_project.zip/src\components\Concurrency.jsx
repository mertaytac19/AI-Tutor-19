// src/components/Concurrency.jsx
import React from "react";
import { useStore } from "../store";
import TutorChat from "./TutorChat";

export default function Concurrency() {
  const { addDecision, goToPhase } = useStore();

  const handleDecision = (label) => {
    addDecision({ step: "concurrency", choice: label });
    if (label === "Queue Isolation (message queue)" ) {
      // Proceed to privacy decision
      goToPhase("privacy");
    } else {
      // Mutex lock also proceeds to privacy decision
      goToPhase("privacy");
    }
  };

  return (
    <div className="w-full max-w-2xl bg-white rounded-xl shadow-lg p-6 space-y-6">
      <h2 className="text-xl font-semibold">Concurrency Decision</h2>
      <p className="mt-4">Choose a strategy to prevent duplicate allocation requests.
      </p>
      <div className="flex space-x-4 mt-4">
        <button
          onClick={() => handleDecision("Mutex Lock (optimistic) ")}
          className="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded"
        >
          Mutex Lock (optimistic)
        </button>
        <button
          onClick={() => handleDecision("Queue Isolation (message queue)")}
          className="flex-1 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded"
        >
          Queue Isolation (message queue)
        </button>
      </div>
      <TutorChat />
    </div>
  );
}
