// src/components/CrisisRoom.jsx
import React from "react";
import { useStore } from "../store";
import TutorChat from "./TutorChat";

export default function CrisisRoom() {
  const { profile, addDecision, goToPhase, decisions, timer } = useStore();

  // Simulated status values
  const activeDrones = 12;
  const errorRate = "8%";

  const handleDecision = (key, label) => {
    addDecision({ step: "architecture", choice: label });
    if (label === "Hot‑patch in production without lock") {
      // Memory leak failure path -> go to ending directly
      goToPhase("ending");
      addDecision({ step: "outcome", result: "memory_leak" });
    } else {
      // Continue to concurrency decision
      goToPhase("concurrency");
    }
  };

  return (
    <div className="w-full max-w-2xl bg-white rounded-xl shadow-lg p-6 space-y-6">
      <h2 className="text-xl font-semibold">Crisis Dashboard</h2>
      <div className="grid grid-cols-3 gap-4">
        <div className="p-2 bg-indigo-100 rounded">Active Drones: {activeDrones}</div>
        <div className="p-2 bg-red-100 rounded">Error Rate: {errorRate}</div>
        {profile.experience === "high" && timer !== null && (
          <div className="p-2 bg-green-100 rounded">Timer: {timer}s</div>
        )}
      </div>
      <p className="mt-4">
        A race condition is causing duplicate package allocation requests. You must decide how to intervene.
      </p>
      <div className="flex space-x-4">
        <button
          onClick={() => handleDecision("arch", "Rollback to previous stable version")}
          className="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded"
        >
          Rollback to previous stable version
        </button>
        <button
          onClick={() => handleDecision("arch", "Hot‑patch in production without lock")}
          className="flex-1 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded"
        >
          Hot‑patch in production without lock
        </button>
      </div>
      <TutorChat />
    </div>
  );
}
