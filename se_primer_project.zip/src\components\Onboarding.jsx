// src/components/Onboarding.jsx
import React, { useState } from "react";
import { useStore } from "../store";

const questions = [
  { id: "experience", label: "Experience Level", options: [{ value: "low", label: "Beginner" }, { value: "high", label: "Expert" }] },
  { id: "role", label: "Current Role", options: [{ value: "devops", label: "DevOps Engineer" }, { value: "sre", label: "Site Reliability Engineer" }, { value: "infra", label: "Infrastructure Engineer" }] },
  { id: "goal", label: "Learning Goal", options: [{ value: "fix", label: "Fix the race condition" }, { value: "opt", label: "Optimize the system" }, { value: "learn", label: "Learn concurrency patterns" }] }
];

export default function Onboarding() {
  const { setProfile, goToPhase, startTimer } = useStore();
  const [answers, setAnswers] = useState({});

  const handleSelect = (qid, value) => {
    setAnswers(prev => ({ ...prev, [qid]: value }));
  };

  const canProceed = questions.every(q => answers[q.id]);

  const handleContinue = () => {
    const profile = {
      experience: answers.experience,
      role: answers.role,
      goal: answers.goal
    };
    setProfile(profile);
    if (profile.experience === "high") {
      startTimer();
    }
    goToPhase("crisis");
  };

  return (
    <div className="w-full max-w-md bg-white rounded-xl shadow-lg p-6 space-y-6">
      <h1 className="text-2xl font-semibold text-center">Welcome, On‑call Engineer</h1>
      {questions.map(q => (
        <div key={q.id}>
          <label className="block font-medium mb-2">{q.label}</label>
          <div className="grid grid-cols-1 gap-2">
            {q.options.map(o => (
              <button
                key={o.value}
                className={`px-4 py-2 rounded border ${answers[q.id] === o.value ? "bg-indigo-600 text-white" : "bg-gray-100"}`}
                onClick={() => handleSelect(q.id, o.value)}
              >
                {o.label}
              </button>
            ))}
          </div>
        </div>
      ))}
      <button
        disabled={!canProceed}
        onClick={handleContinue}
        className={`w-full py-2 mt-4 rounded ${canProceed ? "bg-green-600 hover:bg-green-700" : "bg-gray-300 cursor-not-allowed"} text-white`}
      >
        Continue
      </button>
    </div>
  );
}
