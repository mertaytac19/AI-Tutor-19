// src/store.js
import create from 'zustand';
import { persist } from 'zustand/middleware';

export const useStore = create(
  persist(
    (set, get) => ({
      // phases: onboarding -> crisis -> ending
      phase: 'onboarding',
      // user profile
      profile: {
        experience: 'low', // 'low' or 'high'
        role: '',
        goal: ''
      },
      // decision path tracking
      decisions: [],
      // timer (seconds left) for high‑experience users
      timer: null,
      // start timer for 60 seconds
      startTimer: () => {
        set({ timer: 60 });
        const tick = () => {
          const current = get().timer;
          if (current > 0) {
            set({ timer: current - 1 });
            setTimeout(tick, 1000);
          }
        };
        tick();
      },
      // advance phase
      goToPhase: (newPhase) => set({ phase: newPhase }),
      // set profile
      setProfile: (profile) => set({ profile }),
      // record decision
      addDecision: (decision) =>
        set({ decisions: [...get().decisions, decision] }),
      // reset (used for testing)
      reset: () =>
        set({
          phase: 'onboarding',
          profile: { experience: 'low', role: '', goal: '' },
          decisions: [],
          timer: null
        })
    }),
    { name: 'se-primer-store' }
  )
);
