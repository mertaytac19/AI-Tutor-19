# SE Primer

An interactive, state‑driven educational web app that puts the player in the role of an on‑call Senior Infrastructure Engineer dealing with a high‑concurrency failure in an autonomous drone logistics network.

## Product Decisions (Non‑Features)

1. **Real‑time Telemetry WebSockets were excluded** – the state‑machine simulation provides deterministic evaluation without the overhead and complexity of live network streams.
2. **Persistent User Authentication was excluded** – keeping onboarding friction under **5 seconds** ensures a single‑session learning experience without the need for login flows.
3. **Multi‑language Localization was excluded** – focusing on a single target language allows deeper Socratic evaluation precision and reduces maintenance burden.

---

### Quick Start
```bash
# Install dependencies
npm install
# Run development server
npm run dev
# Open Cypress UI (tests)
npm run test
```

The application is built with **React**, **Vite**, **Tailwind CSS**, and **Zustand** for state management.

---

### Architecture Overview
- **Specification** – `spec.md`
- **UI** – React components under `src/components/`
- **State Machine** – Zustand store (`src/store.js`)
- **AI Tutor** – Socratic logic defined in `src/tutor_prompt.ts` and simulated in `TutorChat.jsx`
- **Evaluation** – `evaluate.js` reads `eval_dataset.json` and validates the tutor's responses.
- **End‑to‑End Tests** – Cypress spec at `cypress/e2e/se_primer_spec.cy.js`
