// src/App.jsx
import React from "react";
import { useStore } from "./store";
import Onboarding from "./components/Onboarding";
import CrisisRoom from "./components/CrisisRoom";
import Concurrency from "./components/Concurrency";
import Privacy from "./components/Privacy";
import Ending from "./components/Ending";

function App() {
  const { phase } = useStore();
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-100 via-purple-50 to-pink-100 p-4">
      {phase === "onboarding" && <Onboarding />}
      {phase === "crisis" && <CrisisRoom />}
      {phase === "concurrency" && <Concurrency />}
      {phase === "privacy" && <Privacy />}
      {phase === "ending" && <Ending />}
    </div>
  );
}

export default App;
