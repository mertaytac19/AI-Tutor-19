// src/components/Privacy.jsx
import React from "react";
import { useStore } from "../store";
import TutorChat from "./TutorChat";

export default function Privacy() {
  const { addDecision, goToPhase } = useStore();

  const handleDecision = (label) => {
    addDecision({ step: "privacy", choice: label });
    // Both decisions lead to ending phase
    goToPhase("ending");
  };

  return (
    <div className="w-full max-w-2xl bg-white rounded-xl shadow-lg p-6 space-y-6">
      <h2 className="text-xl font-semibold">Privacy Decision</h2>
      <p className="mt-4">How will you handle the GPS logs before sharing them?</p>
      <div className="flex space-x-4 mt-4">
        <button
          onClick={() => handleDecision("Anonymize logs (remove lat/long)")}
          className="flex-1 py-2 bg-green-600 hover:bg-green-700 text-white rounded"
        >
          Anonymize logs (remove lat/long)
        </button>
        <button
          onClick={() => handleDecision("Export raw logs to Slack")}
          className="flex-1 py-2 bg-red-600 hover:bg-red-700 text-white rounded"
        >
          Export raw logs to Slack
        </button>
      </div>
      <TutorChat />
    </div>
  );
}
