// cypress/e2e/se_primer_spec.cy.js
/**
 * End‑to‑end test scenarios for SE Primer.
 * Path 1 – Beginner: Low experience → Rollback → Mutex Lock → Anonymize logs → Good ending.
 * Path 2 – Experienced: High experience → Hot‑patch → (memory‑leak) disaster ending.
 */

describe('SE Primer – Beginner path (good ending)', () => {
  it('completes the happy flow', () => {
    cy.visit('/')
    // Onboarding – select low experience, any role and goal
    cy.contains('Beginner').click()
    cy.contains('DevOps Engineer').click()
    cy.contains('Fix the race condition').click()
    cy.contains('Continue').click()

    // Crisis – choose Rollback
    cy.contains('Rollback to previous stable version').click()

    // Concurrency – choose Mutex Lock
    cy.contains('Mutex Lock (optimistic)').click()

    // Privacy – choose Anonymize logs
    cy.contains('Anonymize logs (remove lat/long)').click()

    // Ending – expect good verdict
    cy.contains('Good Ending').should('be.visible')
    cy.contains('Decision Path')
    cy.get('li').should('contain', 'architecture: Rollback to previous stable version')
    cy.get('li').should('contain', 'concurrency: Mutex Lock (optimistic)')
    cy.get('li').should('contain', 'privacy: Anonymize logs (remove lat/long)')
  })
})

describe('SE Primer – Experienced path (disaster ending)', () => {
  it('triggers memory‑leak disaster flow', () => {
    cy.visit('/')
    // Onboarding – high experience
    cy.contains('Expert').click()
    cy.contains('Site Reliability Engineer').click()
    cy.contains('Learn concurrency patterns').click()
    cy.contains('Continue').click()

    // Crisis – choose Hot‑patch
    cy.contains('Hot‑patch in production without lock').click()

    // Ending – expect disaster verdict
    cy.contains('Disaster: Memory leak caused a system crash.').should('be.visible')
    cy.contains('Decision Path')
    cy.get('li').should('contain', 'architecture: Hot‑patch in production without lock')
    cy.get('li').should('contain', 'outcome: memory_leak')
  })
})
