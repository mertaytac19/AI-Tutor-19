# SE Primer Specification (spec.md)

## 1. Problem Statement

The system simulates an **autonomous drone logistics network** used for emergency medical deliveries. Under high concurrency, a **race condition** in the package allocation service leads to **duplicate allocation requests**, causing:
- **Battery depletion** of drones due to redundant trips.
- **Raw GPS logs** being leaked, which contain personally identifiable location data, violating **KVKK/GDPR** regulations.

The educational game places the player in the role of an **on‑call Senior Infrastructure Engineer** who must diagnose and mitigate these issues through a series of interactive decisions.

## 2. Out of Scope (Kapsam Dışı)
- Native mobile builds (iOS/Android).
- Persistent user authentication database.
- Real‑world drone hardware SDKs or communication layers.
- Persistence of state across browser refreshes or server restarts.

## 3. Acceptance Criteria (Kabul Örnekleri)
| ID | Criteria |
|----|----------|
| **AC‑1** | For a **low‑experience player**, the UI must display **contextual hints** and **disable any time pressure** (no countdown). |
| **AC‑2** | For a **high‑experience player**, a **60‑second countdown timer** appears after the scenario narrative, limiting decision time. |
| **AC‑3** | Selecting **"Hot‑patch in production without lock"** routes the player to the **Memory Leak failure state**. |
| **AC‑4** | If the player **sends raw logs to Slack** without masking latitude/longitude, the system flags a **KVKK breach** and ends the game with the corresponding bad ending. |
| **AC‑5** | The **AI Tutor** must **never reveal the exact technical fix**; it should reply only with **Socratic questions** prompting the player to think about locking, idempotency, or data masking. |

## 4. State Machine Flowchart
```plantuml
@startmindmap
* SE Primer
** Start
*** Profile Quiz (Level / Role / Goal)
*** Crisis Intro
*** Decision 1: Architecture
**** Rollback -> continue
**** Hot‑patch -> Memory Leak failure
*** Decision 2: Concurrency
**** Mutex Lock -> continue
**** Queue Isolation -> continue
*** Decision 3: Privacy
**** Anonymize Logs -> Good Ending
**** Raw Export -> KVKK Breach Ending
*** Endings
**** Good Ending
**** Bad Ending – KVKK breach
**** Disaster Ending (e.g., battery depletion)
@endmindmap
```

---

*Generated for the interactive educational application **SE Primer**.*
