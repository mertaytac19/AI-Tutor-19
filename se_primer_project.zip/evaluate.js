// evaluate.js
/**
 * Simple evaluation script for the Socratic AI Tutor.
 * It loads `eval_dataset.json`, feeds each input to a mock tutor
 * (the same logic used in the UI) and checks:
 *   1. The tutor does NOT reveal a direct solution.
 *   2. Classifies the reply as:
 *        - "direct_leak"   (exact fix disclosed)
 *        - "too_cryptic"   (reply is meaningless or asks unrelated question)
 *        - "irrelevant"    (reply does not address the input)
 *   3. Calculates overall pass rate.
 */

import * as fs from "fs";
import path from "path";
import { tutorSystemPrompt } from "./src/tutor_prompt";

// Reuse the mock logic from UI (duplicate here for evaluation)
const mockTutorResponse = (msg, experience) => {
  const low = experience === "low";
  const lower = msg.toLowerCase();
  if (lower.includes("lock")) {
    return low
      ? "Can you think of a way to ensure only one request modifies the allocation state at a time?"
      : "What trade‑offs exist between coarse‑grained and fine‑grained locking here?";
  }
  if (lower.includes("queue")) {
    return low
      ? "How might a message queue help to serialize the allocation work?"
      : "What guarantees would a queue give you compared to a lock?";
  }
  if (lower.includes("log")) {
    return low
      ? "Why is it risky to share raw GPS coordinates with external services?"
      : "What data‑masking technique would satisfy GDPR/KVKK compliance?";
  }
  // Default Socratic fallback
  return low
    ? "What other aspects of the system could be influencing this race condition?"
    : "Which part of the architecture do you suspect is the weakest link?";
};

// Heuristic to detect a direct answer (very naive)
const isDirectAnswer = (reply) => {
  const lower = reply.toLowerCase();
  // Look for phrases that give concrete fixes
  const disallowed = [
    "use a lock",
    "add a mutex",
    "implement a queue",
    "mask the logs",
    "encrypt the logs",
    "rollback",
    "hot‑patch",
    "restart",
    "add rate limiting"
  ];
  return disallowed.some((phrase) => lower.includes(phrase));
};

const classifyReply = (reply) => {
  if (isDirectAnswer(reply)) return "direct_leak";
  // Very short or generic replies are considered too cryptic
  const words = reply.split(/\s+/).filter(Boolean).length;
  if (words < 4) return "too_cryptic";
  return "relevant";
};

const runEvaluation = () => {
  const datasetPath = path.resolve("eval_dataset.json");
  const dataset = JSON.parse(fs.readFileSync(datasetPath, "utf-8"));

  let passed = 0;
  const results = [];

  // Assume we evaluate for both experience levels
  const experiences = ["low", "high"];

  for (const exp of experiences) {
    for (const entry of dataset) {
      const reply = mockTutorResponse(entry.input, exp);
      const classification = classifyReply(reply);
      const pass = classification !== "direct_leak";
      if (pass) passed++;
      results.push({
        id: entry.id,
        experience: exp,
        input: entry.input,
        reply,
        classification,
        pass
      });
    }
  }

  const total = dataset.length * experiences.length;
  const accuracy = ((passed / total) * 100).toFixed(2);

  console.log("--- Evaluation Report ---");
  console.log(`Total cases: ${total}`);
  console.log(`Passed (no direct answer): ${passed}`);
  console.log(`Accuracy: ${accuracy}%`);
  console.log("Sample failures:");
  results
    .filter((r) => !r.pass)
    .slice(0, 5)
    .forEach((r) => {
      console.log(`- [${r.experience}] ${r.input}\n  Reply: ${r.reply}\n  Classification: ${r.classification}`);
    });

  // Optionally write detailed report
  fs.writeFileSync(
    path.resolve("evaluation_report.json"),
    JSON.stringify({ total, passed, accuracy, results }, null, 2)
  );
};

if (require.main === module) {
  runEvaluation();
}
