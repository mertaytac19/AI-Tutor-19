// src/components/Ending.jsx
import React from "react";
import { useStore } from "../store";

export default function Ending() {
  const { decisions, profile } = useStore();

  const lastDecision = decisions[decisions.length - 1] || {};
  const outcome = lastDecision.result || (lastDecision.choice && lastDecision.choice.includes("raw logs") ? "kvkk_breach" : "good");

  const getVerdict = () => {
    if (outcome === "memory_leak") return "Disaster: Memory leak caused a system crash.";
    if (outcome === "kvkk_breach") return "Bad Ending: KVKK/GDPR breach due to raw GPS logs.";
    return "Good Ending: You successfully mitigated the race condition and protected user data.";
  };

  return (
    <div className="w-full max-w-md bg-white rounded-xl shadow-lg p-6 space-y-4 text-center">
      <h2 className="text-2xl font-bold">Scenario Completed</h2>
      <p className="mt-2 text-lg">{getVerdict()}</p>
      <div className="mt-4">
        <h3 className="font-medium">Decision Path</h3>
        <ul className="list-disc list-inside text-left mt-2">
          {decisions.map((d, i) => (
            <li key={i}>{d.step}: {d.choice}</li>
          ))}
        </ul>
      </div>
      <button
        onClick={() => window.location.reload()}
        className="mt-6 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded"
      >
        Play Again
      </button>
    </div>
  );
}
